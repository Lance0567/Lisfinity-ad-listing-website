<?php
/**
 * Template Name: Shortcodes | Product Logo
 * Description: The file that is being used to display product logo shortcode
 *
 * @author pebas
 * @package templates/shortcodes/single
 * @version 1.0.0
 *
 * @var $args
 */

?>

<div class="elementor-product-logo"></div>
